# Slime-Simulation
Project created with Unity 2020.3

Video here: https://www.youtube.com/watch?v=X-iSQQgOd1A

Based on this paper: https://uwe-repository.worktribe.com/output/980579

![Simulation Screenshot](https://raw.githubusercontent.com/SebLague/Images/master/Slime%202.PNG)
![Simulation Screenshot](https://raw.githubusercontent.com/SebLague/Images/master/Slime%201.PNG)
